# deck.js-transition-cube

A transition theme for [deck.js][] which transitions between slides as faces of a rotating 3D cube.
Nested slides are assumed to be full-width and are rotated in like rows of a Rubik's cube.

## Requirements

[deck.js][]

## License

Copyright 2012 Mike Harris

Dual licensed under the [MIT license][] and [GPL license][], consistent with [deck.js][].


[deck.js]: https://github.com/imakewebthings/deck.js
[MIT license]: https://github.com/mikeharris100/deck.js-transition-cube/blob/master/MIT-license.txt
[GPL license]: https://github.com/mikeharris100/deck.js-transition-cube/blob/master/GPL-license.txt
